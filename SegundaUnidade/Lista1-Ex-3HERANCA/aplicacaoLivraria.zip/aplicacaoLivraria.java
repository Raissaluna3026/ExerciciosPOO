public class aplicacaoLivraria {
    private static String nomeLivraria;

    public static String getNomeLivraria(){
        return nomeLivraria;
    }
    public static void setNomeLivraria(String nome){
        nomeLivraria = nome;
    }
}
